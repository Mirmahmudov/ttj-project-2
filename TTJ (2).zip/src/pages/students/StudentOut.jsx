import React from "react";
import Navbar from "../../components/Navbar";
import Sidenav from "../../components/Sidenav";
import Box from "@mui/material/Box";

function StudentOut() {
  return (
    <>
      <Navbar />
      <Box height={70} />

      <Box sx={{ display: "flex" }}>
        <Sidenav />
        <h1>Students out kethgan</h1>
      </Box>
    </>
  );
}

export default StudentOut;
