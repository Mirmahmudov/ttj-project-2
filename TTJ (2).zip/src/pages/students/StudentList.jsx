import React from "react";

function StudentList() {
  return <div>StudentList</div>;
}

export default StudentList;
